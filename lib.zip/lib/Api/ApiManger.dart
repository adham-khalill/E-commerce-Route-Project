// lib/data/api_manager.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'endPoint.dart';

class ApiManager {
  // Sign Up Method
  static Future<Map<String, dynamic>?> signUp({
    required String name,
    required String email,
    required String password,
    required String rePassword,
    required String phone,
  }) async {
    final url = Uri.parse(signUpUrl);

    final body = {
      'name': name,
      'email': email,
      'password': password,
      'rePassword': rePassword,
      'phone': phone,
    };

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        print('Failed to sign up: ${response.body}');
        print("no nigga");
        return null;
      }
    } catch (error) {
      print('Error occurred during sign up: $error');
      return null;
    }
  }

  // Sign In Method
  static Future<Map<String, dynamic>?> signIn({
    required String email,
    required String password,
  }) async {
    final url = Uri.parse(loginUrl);

    final body = {
      'email': email,
      'password': password,
    };

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        print("no nigga");
        return json.decode(response.body);
      }
    } catch (error) {
      print('Error occurred during sign in: $error');
      return null;
    }
  }
}
